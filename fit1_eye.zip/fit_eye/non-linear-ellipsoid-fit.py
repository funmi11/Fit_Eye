## https://jekel.me/2021/A-better-way-to-fit-Ellipsoids/

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
import random

n_one = 20
np.random.seed(123)
noise = np.random.normal(size=(n_one*n_one), loc=0, scale=1e-2)

in_file = "eye_point_cloud.npy"

print("Loading point cloud from ", in_file)
with open( in_file , 'rb') as f:
    points = np.load(f)

print(points.shape)

x = points[:,0]
y = points[:,1]
z = points[:,2]
print("Shape x = ", x.shape )
print("Shape y = ", y.shape )
print("Shape z = ", z.shape )


#sys.exit(0)


import jax.numpy as jnp
from jax import grad
from jax import random
from jax.config import config
config.update('jax_enable_x64', True)
key = random.PRNGKey(0)

gamma_guess = np.random.random(6)
gamma_guess[0] = x.mean()
gamma_guess[1] = y.mean()
gamma_guess[2] = z.mean()

gamma_guess[3] = 10.
gamma_guess[4] = 10.
gamma_guess[5] = 10.



#gamma_guess = jnp.array(gamma_guess)


print('Range of x ', x.min() , "to" , x.max() )
print('Range of x ', y.min() , "to" , y.max() )
print('Range of x ', z.min() , "to" , z.max() )

print("Initial guess of parameters")
for gamma_guess_ in gamma_guess :
  print(gamma_guess_)

print(" ") 

def predict(gamma):
    """
     (x-x0)**2/a**2 +  (y-y0)**2/b**2 +  (z-z0)**2/c**2 = 1

    """

    # compute f hat
    x0 = gamma[0]
    y0 = gamma[1]
    z0 = gamma[2]
    a2 = gamma[3]**2
    b2 = gamma[4]**2
    c2 = gamma[5]**2
    zeta0 = (x - x0)**2 / a2
    zeta1 = (y - y0)**2 / b2
    zeta2 = (z - z0)**2 / c2
    return zeta0 + zeta1 + zeta2


def loss(g):
    # compute mean squared error
    pred = predict(g)
    target = jnp.ones_like(pred)
    mse = jnp.square(pred-target).mean()
    return mse


print(loss(gamma_guess))
print(grad(loss)(gamma_guess))

from scipy.optimize import fmin_bfgs

res = fmin_bfgs(
    loss,
    gamma_guess,
    fprime=grad(loss),
    norm=2.0,
    args=(),
    gtol=1e-17,
    maxiter=None,
    full_output=1,
    disp=1,
    retall=0,
    callback=None
)
#print(res)

#print(type(res))
#print("MSE = " , res[0])
print("MSE = " , res[1])
#print("MSE = " , res[2])
#print("MSE = " , res[3])
print("Function evaluations = " , res[4])
print("Derivative evaluations = " , res[5])

# plot the predictions
u, v = np.meshgrid(np.linspace(0, np.pi*2, 40), np.linspace(0, np.pi, 20))
r = 1.0 / np.sqrt((np.cos(u)/res[0][3])**2 + (((np.sin(u)/res[0][4])**2)*np.sin(v)**2) + ((np.cos(v)/res[0][5])**2))
xhat = np.cos(u)*np.sin(v)*r
yhat = np.sin(u)*np.sin(v)*r
zhat = np.cos(v)*r
xhat = xhat + res[0][0]
yhat = yhat + res[0][1]
zhat = zhat + res[0][2]


print("Fit model")
print(predict.__doc__)


print("Summary fit results")
print(f"FIT, x_0 = {res[0][0]:.2f} mm" )
print(f"FIT, y_0 = {res[0][1]:.2f} mm" )
print(f"FIT, z_0 = {res[0][2]:.2f} mm" )

print(f"FIT, a = {res[0][3]:.1f} mm" )
print(f"FIT, b = {res[0][4]:.1f} mm" )
print(f"FIT, c = {res[0][5]:.1f} mm" )

print("Plottingo")
# plot the predictions
u, v = np.meshgrid(np.linspace(0, np.pi*2, 40), np.linspace(0, np.pi, 20))
r = 1.0 / np.sqrt((np.cos(u)/res[0][3])**2 + (((np.sin(u)/res[0][4])**2)*np.sin(v)**2) + ((np.cos(v)/res[0][5])**2))
xhat = np.cos(u)*np.sin(v)*r
yhat = np.sin(u)*np.sin(v)*r
zhat = np.cos(v)*r
xhat = xhat + res[0][0]
yhat = yhat + res[0][1]
zhat = zhat + res[0][2]


#   3D plot of Ellipsoid
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# subsample pointa
dim = len(x)
print("Selecting 0 to ", dim)
#ipt = random.randint(0,10) 
#print(ipt)
xx = []
yy = []
zz = [] 
for i in range(0,dim,300) :
#   print(i)
   xx.append(x[i])
   yy.append(y[i])
   zz.append(z[i])

xx = np.array(xx)
yy = np.array(yy)
zz = np.array(zz)

ax.scatter(xx, yy, zz, zdir='z', s=20, c='b', rasterized=True)

# plot the fitted model
ax.plot_wireframe(xhat, yhat, zhat, color="r")

plt.savefig('eyeFIT.png', format='png', dpi=300, bbox_inches='tight')
plt.show()
