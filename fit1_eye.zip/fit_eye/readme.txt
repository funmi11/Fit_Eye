Segmentation_right_eye.stl  The stl file of one of the eyes

plot_eye.py  Plots the eye in the file: Segmentation_right_lens.stl

point_cloud.py  Reads in the file Segmentation_right_lens.stl and
                writes out a point cloud of the eye to file: eye_point_cloud.npy

non-linear-ellipsoid-fit.py  Reads in the file eye_point_cloud.npy
                             and fits to an Ellipsoid
